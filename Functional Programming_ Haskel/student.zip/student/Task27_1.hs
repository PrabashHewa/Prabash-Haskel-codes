import Dates

-- Function to parse the input line into separate components
parseInput :: String -> Maybe (String, String, String, String)
parseInput input = case words input of
    ["Event", name, "happens", "at", place, "on", date] -> Just (name, place, "on", date)
    ["Tell", "me", "about", name] -> Just (name, "", "", "")
    ["What", "happens", "on", date] -> Just ("", "", "on", date)
    ["What", "happens", "at", place] -> Just ("", place, "at", "")
    ["Quit"] -> Just ("Quit", "", "", "")
    _ -> Nothing

-- Function to handle the user input and generate the appropriate response
handleInput :: String -> String
handleInput input = 
    let parsedInput = parseInput input
    in case parsedInput of
        Just ("Quit", _, _, _) -> "Bye"
        Just (name, place, "on", date) -> handleWhatHappensOn date
        Just ("", place, "at", "") -> handleWhatHappensAt place
        Just (name, "", "", "") -> handleTellMeAbout name
        Just (name, place, "on", date) -> handleEvent name place date
        Nothing -> "I do not understand that. I understand the following:\n*Event <name> happens at <place> on <date>\n*Tell me about <eventname>\n*What happens on <date>\n*What happens at <place>\n*Quit"
        _ -> "Bad date"

-- Function to handle "Event <name> happens at <place> on <date>"
handleEvent :: String -> String -> String -> String
handleEvent name place date =
    case makeMaybeDate (read $ take 4 date) (read $ drop 5 $ take 7 date) (read $ drop 8 date) of
        Just dateObj -> "Ok"
        Nothing -> "Bad date"

-- Function to handle "Tell me about <eventname>"
handleTellMeAbout :: String -> String
handleTellMeAbout name = 
    let event = findEventByName name
    in case event of
        Just e -> show e
        Nothing -> "I do not know of such event"

-- Function to find an event by name
findEventByName :: String -> Maybe Date
findEventByName name = undefined -- You need to implement this

-- Function to handle "What happens on <date>"
handleWhatHappensOn :: String -> String
handleWhatHappensOn date = 
    let events = findEventsByDate date
    in if null events
        then "Nothing that I know of"
        else unlines $ map show events

-- Function to find events by date
findEventsByDate :: String -> [Date]
findEventsByDate date = undefined -- You need to implement this

-- Function to handle "What happens at <place>"
handleWhatHappensAt :: String -> String
handleWhatHappensAt place = 
    let events = findEventsByPlace place
    in if null events
        then "Nothing that I know of"
        else unlines $ map show events

-- Function to find events by place
findEventsByPlace :: String -> [Date]
findEventsByPlace place = undefined -- You need to implement this

-- Main function to run the dialogue system
main :: IO ()
main = do
    putStrLn "Welcome to the Calendar Dialogue System!"
    putStrLn "Please input your commands:"
    dialogueLoop

-- Function to keep the dialogue going until the user quits
dialogueLoop :: IO ()
dialogueLoop = do
    putStr "> "
    input <- getLine
    putStrLn $ "> " ++ input
    let response = handleInput input
    putStrLn response
    if response /= "Bye" then dialogueLoop else return ()
